# servicenow_agent/services/servicenow_polling.py

from tools import tool_fetch_query_incident

def fetch_intercompany_incidents():
    query = "short_descriptionLIKEIntercompany^state!=7"
    
    response = tool_fetch_query_incident(query)
    incidents = response.json().get("result", [])

    return incidents