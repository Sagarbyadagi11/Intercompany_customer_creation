# tools/tools2.py

import requests
import json

SERVICENOW_INSTANCE = "https://tataamericaintlcorpdemo3.service-now.com"
username = "2497505"
password = "ServiceNow@2025!!"

def tool_fetch_query_incident(query=None):
    url = f"{SERVICENOW_INSTANCE}/api/now/table/incident"
    
    params = {
        "sysparm_query": query,
        "sysparm_display_value": "true"
    }

    try:
        response = requests.get(
            url,
            auth=(username, password),
            headers={"Accept": "application/json"},
            params=params,
            timeout=10
        )
        response.raise_for_status()

        resp_json = response.json()
        
        for item in resp_json.get("result", []):
            item["ticket"] = item.get("number")

        response._content = json.dumps(resp_json).encode('utf-8')
        return response

    except requests.exceptions.RequestException as e:
        print(f"❌ Error in querying incidents: {e}")
        return None