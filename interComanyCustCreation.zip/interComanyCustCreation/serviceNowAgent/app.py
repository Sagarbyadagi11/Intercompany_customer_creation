# servicenow_agent/app.py

from fastapi import FastAPI, Body, HTTPException
from polling_agent import start_polling
from servicenow_polling import fetch_intercompany_incidents

app = FastAPI(title="ServiceNow Polling Agent")

@app.on_event("startup")
async def startup():
    """
    Start the polling agent as soon as the app starts.
    """
    print("Starting ServiceNow Polling Agent")
    start_polling()

@app.post("/fetch_incidents")
async def fetch_incidents():
    incidents = fetch_intercompany_incidents()
    if incidents:
        return {"status": "success", "incidents": incidents}
    else:
        raise HTTPException(status_code=404, detail="No incidents found")