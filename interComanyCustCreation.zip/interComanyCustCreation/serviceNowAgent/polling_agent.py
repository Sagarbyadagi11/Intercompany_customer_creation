# servicenow_agent/polling_agent.py

import time
from servicenow_polling import fetch_intercompany_incidents

POLL_INTERVAL = 30  

def start_polling():
    print("🚀 ServiceNow Polling Agent Started")

    processed_tickets = set()  

    while True:
        try:
            incidents = fetch_intercompany_incidents()

            if not incidents:
                print(" No incidents found")
            else:
                print(f"Found {len(incidents)} incidents")

                for inc in incidents:
                    ticket = inc.get("ticket")

                    if ticket in processed_tickets:
                        continue  

                    print(f"New Incident: {ticket}")
                    print(f"   Desc: {inc.get('short_description')}")

                    
                    processed_tickets.add(ticket)


                    print(f"   Processing ticket {ticket}...")

        except Exception as e:
            print(f"❌ Polling Error: {e}")

        time.sleep(POLL_INTERVAL) 