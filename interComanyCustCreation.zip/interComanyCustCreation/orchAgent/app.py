# orchestrator/app.py

from fastapi import FastAPI, Body, HTTPException
from orchAgent.orchestrator_agent import process_incident
from orchAgent.services.orchestrator_services import handle_ticket

app = FastAPI(title="Orchestrator App")

@app.post("/process_ticket")
async def process_ticket_endpoint(ticket_data: dict = Body(...)):
    try:
        result = process_incident(ticket_data)
        return {"status": "success", "result": result}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error processing ticket: {e}")